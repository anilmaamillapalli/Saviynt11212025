package com.kpmg.hcmatom.constants;

/**
 * This class is used to define all constant values
 * 
 * @author ajinkyachavan
 *
 */
public class Constants {

	//EMP URL to Worker URL Conversion Changes
	public final static String FIRST_NAME = "FirstName";
	//public final static String MIDDLE_NAME = "MiddleName";
	public final static String MIDDLE_NAME = "MiddleNames";
	public final static String LAST_NAME = "LastName";
	public final static String DISPLAY_NAME = "DisplayName";
	//public final static String PREFERRED_NAME = "PreferredName";
	public final static String PREFERRED_NAME = "KnownAs";
	public final static String PERSON_NUMBER = "PersonNumber";
	//public final static String HIRE_DATE = "HireDate";					
	public final static String HIRE_DATE = "StartDate";	
	public final static String TERMINATION_DATE = "TerminationDate";
	public final static String PERSON_ID = "PersonId";
	//public final static String EMP_WORKER_TYPE = "WorkerType";

	// Worker API HCM Attributes
	public final static String WORKER_TYPE = "WorkerType";
	public final static String ASSIGNMENT_NAME = "AssignmentName";
	public final static String JOB_CODE = "JobCode";
	public final static String LOCATION_CODE = "LocationCode";
	public final static String DEPARTMENT_NAME = "DepartmentName";
	public final static String LEGALEMPLOYER_NAME = "LegalEmployerName";
	public final static String ASSIGNMENT_STATUS_TYPE = "AssignmentStatusType";
	public final static String PROJECTED_START_DATE = "ProjectedStartDate";
	public final static String MANAGER_ASSIGNMENT_ID = "ManagerAssignmentId";
	public final static String ASSIGNMENT_ID = "AssignmentId";
	public final static String LOCATION_ID = "LocationId";
	public final static String WORK_AT_HOME_FLAG = "WorkAtHomeFlag";
	public final static String ACTION_CODE = "ActionCode";
	public final static String USER_PERSON_TYPE = "UserPersonType";
	public final static String PAY_RULE = "payRule";
	public final static String ASSIGNMENT_CATEGORY = "AssignmentCategory";
	public final static String POSITION_ID = "PositionId";
	public final static String NORMAL_HOURS = "NormalHours";
	public final static String FREQUENCY = "Frequency";
	public final static String PEOPLE_GROUP = "PeopleGroup";
	public final static String GRADE_ID = "GradeId";

	// Date format
	public final static String SIMPLE_DATE_FORMAT = "yyyy-MM-dd";
	public final static String ATOM_FEED_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
	public final static String LOG_DATE_FORMAT = "yyyyMMdd_HH_mm_ss";

	// Oracle HCM Atom Feed log path
   public final static String SAVIYNT_LOG_PATH = "/datadrive/sharedappdrive/saviynt/logs/OracleHCMAtomFeed_";

	public final static String LOG_EXTENSION = ".log";

	// Oracle HCM Connection timeout

	public final static int CONNECTION_TIMEOUT = 600;

	// UTC time Zone
	public final static String TIME_ZONE = "UTC";

	// Atom Feed URL Configuration
	public final static String UPDATED_MIN = "?updated-min=";
	public final static String UPDATED_MAX = "&updated-max=";
	public final static String PAGE = "&page=";
	public final static String ORDER_BY_PAGE_SIZE = "&orderBy=updated:asc&page-size=";

	// Atom Feed Attribute

	public final static String CONTEXT = "Context";
	public final static String PERSON_NAME = "PersonName";
	public final static String EFFECTIVE_DATE = "EffectiveDate";
	public final static String CHANGED_ATTRIBUTES = "Changed Attributes";
	public final static String ACTUAL_TERMINATION_DATE = "ActualTerminationDate";
	public final static String NEW = "new";

	// SQL Queries
	public final static String SELECT_FROM = "Select * from ";
	public final static String CURRENT_ENDPOINT = "CURRENTENDPOINTS";
	public final static String DELETE_FROM = "DELETE FROM ";
	public final static String NEW_USER_DATA = "NEWUSERDATA";
	public final static String INSERT_STATEMENT = "(firstName,middleName,lastname,customproperty25,preferedfirstname,employeeId,startdate,"
			+ "enddate,employeetype,jobcode,locationnumber,departmentname,"
			+ "companyname,statuskey,employeeclass,customproperty6,customproperty7,"
			+ "customproperty8,customproperty9,customproperty10,customproperty11,"
			+ "customproperty12,customproperty14,customproperty15,customproperty16,customproperty19,customproperty20,customproperty21,customproperty23,customproperty26,customproperty28) VALUES "
			+ " (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?);";

	// User Type

	public final static String PENDING_WORKER = "Pending worker";

	public final static String TRUE = "true";
	public final static String FALSE = "false";

	// Regular expression to trim special character from first name and last name

	public final static String REGULAR_EXPRESSION = "[^a-zA-Z0-9]";

	// Oracle HCM Configuration Constant

	public final static String CUSTOM_PROPERTY_1 = "customproperty1";
	public final static String CUSTOM_PROPERTY_2 = "customproperty2";
	public final static String CUSTOM_PROPERTY_3 = "customproperty3";
	public final static String CUSTOM_PROPERTY_4 = "customproperty4";
	public final static String CUSTOM_PROPERTY_5 = "customproperty5";
	public final static String CUSTOM_PROPERTY_6 = "customproperty6";
	public final static String CUSTOM_PROPERTY_7 = "customproperty7";
	public final static String CUSTOM_PROPERTY_8 = "customproperty8";
	public final static String CUSTOM_PROPERTY_9 = "customproperty9";
	public final static String CUSTOM_PROPERTY_10 = "customproperty10";
	public final static String CUSTOM_PROPERTY_11 = "customproperty11";
	public final static String CUSTOM_PROPERTY_12 = "customproperty12";

	// Store Procedure call constant

	public final static String STORE_PROCEDURE_CALL = " call ";
	public final static String STORE_PROCEDURE_EXECUTE = " execute ";

	// Atom Feed Operations

	public final static String TERMINATION = "termination";
	public final static String EMP_UPDATE = "empupdate";
	public final static String EMP_ASSIGNMENT = "empassignment";

	// Employee and Worker API URL constants

	public final static String URL_EFFECTIVE_DATE = "&effectiveDate=";

	// Fetching employee record constants
	public final static String TOTAL_RESULTS = "totalResults";
	public final static String ITEMS = "items";
	public final static String WORKER_TYPE_E = "E";
	public final static String NAMES = "names";
	public final static String WORK_RELATION_SHIPS = "workRelationships";
	public final static String ASSIGNMENTS = "assignments";
	public final static String ACTIVE = "Active";
	public final static String MANAGERS = "managers";
	public final static String MANAGER_TYPE="ManagerType";
	public final static String LINE_MANAGER="LINE_MANAGER";
	public final static String ASSIGNMENTS_DFF = "assignmentsDFF";
	public static final String PERIODOFSERVICEID = "PeriodOfServiceId";
}
