package com.kpmg.hcmatom;

import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.kpmg.hcmatom.constants.Constants;
import com.kpmg.hcmatom.usermodel.EmpWorkerModel;
import com.kpmg.hcmatom.usermodel.HCMConfigModel;
import com.sun.syndication.feed.synd.SyndContentImpl;
import com.sun.syndication.feed.synd.SyndEntry;
import com.sun.syndication.feed.synd.SyndFeed;
import com.sun.syndication.io.SyndFeedInput;
import com.sun.syndication.io.XmlReader;

/**
 * This class is use to read atom feed data for newhire, termination, empupdate,
 * empassignment operations.
 * 
 * @author Ajinkya Chavan
 *
 */
public class AtomFeedReader {

	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	private String personName = null;
	private String personNumber = null;
	private String effectiveDate = null;

	/**
	 * This employeeRecordCollectionList field is used to store atom feed data.
	 */
	HashMap<String, List<String>> employeeRecordCollectionList = new HashMap<>();

	
	/**
	 * Define EmpWorkerModel POJO list to store values
	 */
	List<EmpWorkerModel> list = new ArrayList<>();

	/**
	 * The method is use to reader atom feed data and store in
	 * employeeRecordCollectionList hashmap with
	 * personNumber,personName,effectiveDate, and actualTerminateDate
	 * 
	 * @param getHcmConfig
	 *            This parameter is used to get atom feed configuration values.
	 * @return This method return list of EmpWorkerModel POJO
	 * @throws Exception
	 *             Throws high level exception occurred in this class while executing
	 *             custom code.
	 */
	public List<EmpWorkerModel> feedReader(HCMConfigModel getHcmConfig) throws Exception {

		String METHOD_NAME = "AtomFeedReader/feedReader() ";

		LOGGER.info("Entered " + METHOD_NAME);
		LOGGER.info(METHOD_NAME + " getHcmConfig " + getHcmConfig);
		LOGGER.info("#################### FeedReader method started ####################");
		try {

			String[] operations = getHcmConfig.getOperation().split(",");

			// updated_min value
			String current_date_minus;

			// Get Current UTC time and minus no of days from current date to calculate
			if (getHcmConfig.getCurrentTimeMinus() != null && !getHcmConfig.getCurrentTimeMinus().isEmpty()) {

				current_date_minus = DateTimeFormatter.ofPattern(Constants.ATOM_FEED_DATE_FORMAT)
						.withZone(ZoneId.of(Constants.TIME_ZONE)).format(Instant.now()
								.minus(Long.parseLong(getHcmConfig.getCurrentTimeMinus()), ChronoUnit.MINUTES));
				LOGGER.info("**** Atom feed is configured with time diference :: " + getHcmConfig.getCurrentTimeMinus()
						+ " minutes ****");

			}

			else {

				current_date_minus = DateTimeFormatter.ofPattern(Constants.ATOM_FEED_DATE_FORMAT)
						.withZone(ZoneId.of(Constants.TIME_ZONE)).format(Instant.now()
								.minus(Long.parseLong(getHcmConfig.getCurrentDateMinus()), ChronoUnit.DAYS));
			}

			int total_feed_size = 0;

			String updated_min = current_date_minus;

			LOGGER.info("updated_min : " + updated_min);

			// Get Current UTC time and add 15 days to current date

			Instant current_date_plus_max = Instant.now().plus(Long.parseLong(getHcmConfig.getFutureDate()),
					ChronoUnit.DAYS);

			// Set future 60 min of current date
			String current_date = DateTimeFormatter.ofPattern(Constants.ATOM_FEED_DATE_FORMAT)
					.withZone(ZoneId.of(Constants.TIME_ZONE))
					.format(Instant.now().plus(Long.parseLong(getHcmConfig.getFurturemin()), ChronoUnit.MINUTES));

			LOGGER.info("current_date" + current_date);
			// Set max date as current date
			// String updated_max = current_date_plus_max.toString();

			String updated_max = DateTimeFormatter.ofPattern(Constants.ATOM_FEED_DATE_FORMAT).withZone(ZoneId.of(Constants.TIME_ZONE))
					.format(current_date_plus_max);

			LOGGER.info("updated_max : " + updated_max);

			// Get Encrypted Key

			String encryptedKey = getHcmConfig.getEncryptKey();

			Decryption decrypt = new Decryption();
			String password = decrypt.passwordDecrypt(encryptedKey);

			// Set Authentication and Authorization
			Authenticator.setDefault(new Authenticator() {

				public PasswordAuthentication getPasswordAuthentication() {
					LOGGER.info("######## Setting Authentication and Authorization ########");
					return new PasswordAuthentication(getHcmConfig.getUserName(), password.toCharArray());
				}
			});

			// Fetch PersonID and Person name from newhire,empupdate,termination api

			for (String operation : operations) {
				int page = 0; // starts at page 1 since page++ in while loop
				LOGGER.info("####################################################");
				LOGGER.info("# Fetch record for operation ::" + operation);
				LOGGER.info("####################################################");
				boolean hasItems = true;
				while (hasItems) {
					hasItems = false;
					page++;
					URL feedUrl;
					if (operation.contains("newhire")) {

						feedUrl = new URL(getHcmConfig.getBaseUrl() + getHcmConfig.getAtomFeedUrl() + operation
								+ Constants.UPDATED_MIN + updated_min + Constants.UPDATED_MAX + updated_max + Constants.PAGE+ page
								+ Constants.ORDER_BY_PAGE_SIZE + getHcmConfig.getPageSize());
					}

					else if (operation.contains("termination")) {

						String pastTermMinDate = DateTimeFormatter.ofPattern(Constants.ATOM_FEED_DATE_FORMAT)
								.withZone(ZoneId.of(Constants.TIME_ZONE)).format(Instant.now()
										.minus(Long.parseLong(getHcmConfig.getCurrentDateMinus()), ChronoUnit.DAYS));

						feedUrl = new URL(getHcmConfig.getBaseUrl() + getHcmConfig.getAtomFeedUrl() + operation
								+Constants.UPDATED_MIN + pastTermMinDate +  Constants.UPDATED_MAX+ current_date +Constants.PAGE + page
								+ Constants.ORDER_BY_PAGE_SIZE + getHcmConfig.getPageSize());
					} else {

						feedUrl = new URL(getHcmConfig.getBaseUrl() + getHcmConfig.getAtomFeedUrl() + operation
								+ Constants.UPDATED_MIN  + updated_min + Constants.UPDATED_MAX + current_date + Constants.PAGE + page
								+ Constants.ORDER_BY_PAGE_SIZE  + getHcmConfig.getPageSize());

					}

					LOGGER.info("Feed Url :: " + feedUrl);

					// Romo API is used to parse atom feed
					SyndFeedInput input = new SyndFeedInput();
					SyndFeed feed = input.build(new XmlReader(feedUrl));

					JSONObject jsonObj = null;
					String actualTerminateDate = null;

					// Get the entry items from atom feed...
					if (feed.getEntries().size() > 0) {
						LOGGER.info("Atom feed size for ::" + operation + " is ::" + feed.getEntries().size()
								+ ":: Page number :: " + page);
						total_feed_size += feed.getEntries().size();
						hasItems = true;

						for (SyndEntry entry : (List<SyndEntry>) feed.getEntries()) {

							for (SyndContentImpl content : (List<SyndContentImpl>) entry.getContents()) {

								try {
									jsonObj = new JSONObject(content.getValue().toString());
									personNumber = (jsonObj.getJSONArray(Constants.CONTEXT).getJSONObject(0)
											.getString(Constants.PERSON_NUMBER));
									personName = (jsonObj.getJSONArray(Constants.CONTEXT).getJSONObject(0)
											.getString(Constants.PERSON_NAME));
									effectiveDate = (jsonObj.getJSONArray(Constants.CONTEXT).getJSONObject(0)
											.getString(Constants.EFFECTIVE_DATE));
									if (jsonObj.has((Constants.CHANGED_ATTRIBUTES))) {

										JSONObject changeattribute = jsonObj.getJSONArray(Constants.CHANGED_ATTRIBUTES)
												.getJSONObject(0);

										if (changeattribute.has(Constants.ACTUAL_TERMINATION_DATE)) {

											JSONObject items = (jsonObj.getJSONArray(Constants.CHANGED_ATTRIBUTES)
													.getJSONObject(0).getJSONObject(Constants.ACTUAL_TERMINATION_DATE));

											actualTerminateDate = items.isNull(Constants.NEW) ? ""
													: String.valueOf(items.get(Constants.NEW));

											LOGGER.info("Actual Termination date :: " + actualTerminateDate);
										}
									}

								} catch (JSONException e) {
									e.printStackTrace();
									throw e;
								}
							}

							// Store atom feed data into employeeRecordCollectionList hashmap
							employeeRecordCollectionList.put(personNumber,
									Arrays.asList(personName, effectiveDate, operation, actualTerminateDate));

						}

						LOGGER.info("EmployeeRecordCollectionList :: "+ employeeRecordCollectionList.toString());
					} else {
						LOGGER.info("####################################################");
						LOGGER.info("No records in feed found in " + operation);
						LOGGER.info("####################################################");
						LOGGER.info("Existing process as there are no record into Atom feed");

					}
				}
			}

			for (Map.Entry empRecord : employeeRecordCollectionList.entrySet()) {
				LOGGER.info(empRecord.getKey() + " " + empRecord.getValue());
			}

			LOGGER.info("####################################################");
			LOGGER.info("Total atom feed size for ::" + total_feed_size);
			LOGGER.info("Total unique record size in map ::" + employeeRecordCollectionList.size());
			LOGGER.info("####################################################");

			ReadEmpWorkerRecord read = new ReadEmpWorkerRecord();

			if (!employeeRecordCollectionList.isEmpty() && employeeRecordCollectionList != null) {
				try {
					
					//ReadEmpRecord method is called to read data from employee and worker API
					list = read.readEmpRecord(employeeRecordCollectionList, getHcmConfig);
			
				} catch (Exception e) {

					e.printStackTrace();
					throw e;
				}

			} else {

				LOGGER.info("Employee record collection is empty");

			}

		}

		catch (Exception e) {

			e.printStackTrace();
			throw e;
		}

		finally {
			LOGGER.info("Exit " + METHOD_NAME);
		}
		return list;
	}

}
