package com.kpmg.hcmatom.usermodel;

/**
 * This is POJO class that is used to set values of Oracle HCM Atom Feed, Employee and Worker API configuration.
 * @author ajinkyachavan
 *
 */
public class HCMConfigModel {

	
	/** This method is used to get base Oracle HCM url.
	 * @return baseUrl
	 */
	public String getBaseUrl() {
		return baseUrl;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "HCMConfigModel [baseUrl=" + baseUrl + ", userName=" + userName + ", pageSize=" + pageSize
				+ ", currentDateMinus=" + currentDateMinus + ", currentTimeMinus=" + currentTimeMinus
				+ ", hoursInterval=" + hoursInterval + ", futureDate=" + futureDate + ", furturemin=" + furturemin
				+ ", operation=" + operation + ", atomFeedUrl=" + atomFeedUrl + ", empsUrl=" + empsUrl + ", workerUrl="
				+ workerUrl + "]";
	}

	/** This method is used to set base Oracle HCM url in POJO class.
	 * @param baseUrl This paramter is used to store base URL of Oracle HCM.
	 */
	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	/** This method is used to set service account username of Oracle HCM in POJO class.
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/** This method is used to get service account username of Oracle HCM in POJO class.
	 * @param userName This parameter holds Oracle HCM service account username.
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/** This method is used to get encrypted key of Oracle HCM service account username in POJO class.
	 * @return encryptKey
	 */
	
	public String getEncryptKey() {
		return encryptKey;
	}

	/** This method is used to set encrypted key of Oracle HCM service account username in POJO class.
	 * @param encryptKey This parameter holds encypted key of Oracle HCM service account.
	 */
	
	
	public void setEncryptKey(String encryptKey) {
		this.encryptKey = encryptKey;
	}

	/** This method is used to get pageSize of Oracle HCM Atom Feed in POJO class.
	 * @return pageSize
	 */
	
	public String getPageSize() {
		return pageSize;
	}
	
	/** This method is used to set pageSize of Oracle HCM Atom Feed in POJO class.
	 * @param pageSize This parameter holds pagesize of Oracle HCM Atom Feed.
	 */

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	/** This method is used to get past date atom feed data in POJO class.
	 * @return currentDateMinus
	 */
	
	public String getCurrentDateMinus() {
		return currentDateMinus;
	}

	/** This method is used to set past date atom feed data in POJO class.
	 * @param currentDateMinus This parameter holds date which is substracted with number of days mentioned in Oracle HCM Atom Feed endpoint configuration.
	 */
	
	public void setCurrentDateMinus(String currentDateMinus) {
		this.currentDateMinus = currentDateMinus;
	}
	
	/** This method is used to get operations such as newhire, empupdate,termination, empassignment in POJO class.
	 * @return operation
	 */

	public String getOperation() {
		return operation;
	}

	/** This method is used to set operations such as newhire, empupdate,termination, empassignment in POJO class.
	 * @param operation This parameter holds operations as newhire, empupdate,termination, empassignment.
	 */
	
	public void setOperation(String operation) {
		this.operation = operation;
	}
	
	/** This method is used to get atom feed url in POJO class.
	 * @return atomFeedUrl
	 */
	
	public String getAtomFeedUrl() {
		return atomFeedUrl;
	}

	/** This method is used to set atom feed url in POJO class.
	 * @param atomFeedUrl This parameter holds Oracle HCM Atom Feed URL
	 */
	
	public void setAtomFeedUrl(String atomFeedUrl) {
		this.atomFeedUrl = atomFeedUrl;
	}


	/** This method is used to get employee API url in POJO class.
	 * @return empsUrl
	 */
	
	public String getEmpsUrl() {
		return empsUrl;
	}


	/** This method is used to set employee API url in POJO class.
	 * @param empsUrl This parameter holds employee API url.
	 */
	public void setEmpsUrl(String empsUrl) {
		this.empsUrl = empsUrl;
	}

	/** This method is used to get worker API url in POJO class.
	 * @return workerUrl
	 */
	
	public String getWorkerUrl() {
		return workerUrl;
	}

	/** This method is used to set worker API url in POJO class.
	 * @param workerUrl This parameter holds worker API.
	 */
	public void setWorkerUrl(String workerUrl) {
		this.workerUrl = workerUrl;
	}

	
	private String baseUrl;
	private String userName;
	private String encryptKey;
	
	private String pageSize;
	
	private String currentDateMinus;
	private String currentTimeMinus;
	
	private String hoursInterval;
	
	private String futureDate;
	
	/** This method is used to get future date to fetch record from Oracle HCM Atom Feed.
	 * @return futureDate
	 */
	public String getFutureDate() {
		return futureDate;
	}

	/** This method is used to set future date to fetch record from Oracle HCM Atom Feed.
	 * @param futureDate This parameter holds future date that is set in Oracle HCM Atom Feed endpoint.
	 */
	public void setFutureDate(String futureDate) {
		this.futureDate = futureDate;
	}

	/** This method is used to get future date minutes to fetch record from Oracle HCM Atom Feed.
	 * @return furturemin
	 */
	public String getFurturemin() {
		return furturemin;
	}

	/** This method is used to set future date minutes to fetch record from Oracle HCM Atom Feed.
	 * @param furturemin This parameter holds addition of minutes in current date that is set in Oracle HCM Atom Feed endpoint.
	 */
	public void setFurturemin(String furturemin) {
		this.furturemin = furturemin;
	}

	private String furturemin;
	
	/** This method is used to get current time minus to fetch record from Oracle HCM Atom Feed.
	 *@return currentTimeMinus
	 */
	
	public String getCurrentTimeMinus() {
		return currentTimeMinus;
	}


	/** This method is used to set current time minus to fetch record from Oracle HCM Atom Feed.
	 *@param currentTimeMinus This parameter holds current time is substracted to fetch past record that is set in Oracle HCM Atom Feed endpoint.
	 */
	public void setCurrentTimeMinus(String currentTimeMinus) {
		this.currentTimeMinus = currentTimeMinus;
	}


	//Operations that need to perform from atom feed
	private String operation;
	
	//Atom Feed url
	private String atomFeedUrl;
	
	//Employee API 
	private String empsUrl;
	
	
	//Worker API 
	private String workerUrl;
	
}
