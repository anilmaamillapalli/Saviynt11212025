package com.kpmg.hcmatom.usermodel;

/**
 * This is POJO class that is used to set values for Employee and Worker API
 * attributes
 * 
 * @author ajinkyachavan
 *
 */
public class EmpWorkerModel {

	// Employee API Related Attribute
	private String firstName;
	private String middleName;
	private String lastName;
	private String displayName;
	private String preferredName;
	private String personNumber;
	private String hireDate;
	private String terminationDate;
	private String workerType;
	private String personId;

	// Worker API Related Attributes
	private String jobCode;
	private String locationCode;
	private String departmentName;
	private String legalEmployerName;
	private int assignmentStatusType;
	private String projectedStartDate;
	private String managerAssignmentId;
	private String assignmentId;
	private String locationId;
	private String workAtHomeFlag;
	private String actionCode;
	private String assignmentName;
	private String assignmentCategory;
	private String positionId;
	private String userPersonType;
	private String payRule;
	private String frequency;
	private String normalHours;
	private String peopleGroup;
	private String futureTermHireDate;
	private String gradeId;

	/**
	 * @return the gradeId
	 */
	public String getGradeId() {
		return gradeId;
	}

	/**
	 * @param gradeId the gradeId to set
	 */
	public void setGradeId(String gradeId) {
		this.gradeId = gradeId;
	}

	/**
	 * This method is use to get value, if user is future terminate or hire date.
	 * 
	 * @return the futureTermHireDate
	 */
	public String getFutureTermHireDate() {
		return futureTermHireDate;
	}

	/**
	 * This method is use to set value, if user is future terminate or hire date.
	 * 
	 * @param futureTermHireDate
	 *            the futureTermHireDate to set
	 */
	public void setFutureTermHireDate(String futureTermHireDate) {
		this.futureTermHireDate = futureTermHireDate;
	}

	/**
	 * This method is use to get value of getPeopleGroup in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return peopleGroup
	 */
	public String getPeopleGroup() {
		return peopleGroup;
	}

	/**
	 * This method is use to set value of peopleGroup in EmpWorkerModel POJO class.
	 * 
	 * @param peopleGroup
	 *            This parameter is used to set peopleGroup.
	 */
	public void setPeopleGroup(String peopleGroup) {
		this.peopleGroup = peopleGroup;
	}

	/**
	 * This method is use to get value of getNormalHours in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return normalHours This parameter is used to set getNormalHours.
	 */
	public String getNormalHours() {
		return normalHours;
	}

	/**
	 * This method is use to set value of setNormalHours in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param normalHours
	 *            This parameter is used to set setNormalHours.
	 */

	public void setNormalHours(String normalHours) {
		this.normalHours = normalHours;
	}

	/**
	 * This method is use to get value of getFrequency in EmpWorkerModel POJO class.
	 * 
	 * @return frequency This parameter is used to set getFrequency.
	 */
	public String getFrequency() {
		return frequency;
	}

	/**
	 * This method is use to set value of setFrequency in EmpWorkerModel POJO class.
	 * 
	 * @param frequency
	 *            This parameter is used to set setFrequency.
	 */
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EmpWorkerModel [firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName
				+ ", displayName=" + displayName + ", preferredName=" + preferredName + ", personNumber=" + personNumber
				+ ", hireDate=" + hireDate + ", terminationDate=" + terminationDate + ", workerType=" + workerType
				+ ", personId=" + personId + ", jobCode=" + jobCode + ", locationCode=" + locationCode
				+ ", departmentName=" + departmentName + ", legalEmployerName=" + legalEmployerName
				+ ", assignmentStatusType=" + assignmentStatusType + ", projectedStartDate=" + projectedStartDate
				+ ", managerAssignmentId=" + managerAssignmentId + ", assignmentId=" + assignmentId + ", locationId="
				+ locationId + ", workAtHomeFlag=" + workAtHomeFlag + ", actionCode=" + actionCode + ", assignmentName="
				+ assignmentName + ", assignmentCategory=" + assignmentCategory + ", positionId=" + positionId
				+ ", userPersonType=" + userPersonType + ", payRule=" + payRule + ", frequency=" + frequency
				+ ", normalHours=" + normalHours + ", peopleGroup=" + peopleGroup + ", futureTermHire="
				+ futureTermHireDate + ", gradeId=" + gradeId+ "]";
	}

	/**
	 * This method is use to get value of getUserPersonType in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return userPersonType This parameter is used to set getUserPersonType.
	 */

	public String getUserPersonType() {
		return userPersonType;
	}

	/**
	 * This method is use to set value of userPersonType in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param userPersonType
	 *            This parameter is used to set userPersonType.
	 */

	public void setUserPersonType(String userPersonType) {
		this.userPersonType = userPersonType;
	}

	/**
	 * This method is use to get value of getPersonId in EmpWorkerModel POJO class.
	 * 
	 * @return personId This parameter is used to set getPersonId.
	 */

	public String getPersonId() {
		return personId;
	}

	/**
	 * This method is use to set value of personId in EmpWorkerModel POJO class.
	 * 
	 * @param personId
	 *            This parameter is used to set personId.
	 */

	public void setPersonId(String personId) {
		this.personId = personId;
	}

	/**
	 * This method is use to get value of getAssignmentCategory in EmpWorkerModel
	 * POJO class.
	 * 
	 * @return assignmentCategory This parameter is used to set
	 *         getAssignmentCategory.
	 */

	public String getAssignmentCategory() {
		return assignmentCategory;
	}

	/**
	 * This method is use to set value of assignmentCategory in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param assignmentCategory
	 *            This parameter is used to set assignmentCategory.
	 */

	public void setAssignmentCategory(String assignmentCategory) {

		if (assignmentCategory.equalsIgnoreCase("FR")) {

			this.assignmentCategory = "Full-time regular";
		} else if (assignmentCategory.equalsIgnoreCase("FT")) {

			this.assignmentCategory = "Full-time temporary";
		}

		else if (assignmentCategory.equalsIgnoreCase("PR")) {

			this.assignmentCategory = "Part-time regular";
		}

		else if (assignmentCategory.equalsIgnoreCase("PT")) {

			this.assignmentCategory = "Part-time temporary";
		} else {
			this.assignmentCategory = assignmentCategory;
		}
	}

	/**
	 * This method is use to get value of payRule in EmpWorkerModel POJO class.
	 * 
	 * @return payRule This parameter is used to set payRule.
	 */
	public String getPositionId() {
		return positionId;
	}

	/**
	 * This method is use to set value of positionId in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param positionId
	 *            This parameter is used to set positionId.
	 */
	public void setPositionId(String positionId) {
		this.positionId = positionId;
	}

	/**
	 * This method is use to get value of getPayRule in EmpWorkerModel POJO class.
	 * 
	 * @return payRule This parameter is used to set getPayRule.
	 */

	public String getPayRule() {
		return payRule;
	}

	/**
	 * This method is use to set value of payRule in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param payRule
	 *            This parameter is used to set payRule.
	 */
	
	
	public void setPayRule(String payRule) {
		this.payRule = payRule;
	}

	/**
	 * This method is use to get value of getAssignmentName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return assignmentName This parameter is used to set getAssignmentName.
	 */
	public String getAssignmentName() {
		return assignmentName;
	}

	
	/**
	 * This method is use to set value of assignmentName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param assignmentName
	 *            This parameter is used to set assignmentName.
	 */
	
	
	public void setAssignmentName(String assignmentName) {
		if (assignmentName.equalsIgnoreCase("Active"))
			assignmentName = "1";
		else
			assignmentName = "0";
		this.assignmentName = assignmentName;
	}

	/**
	 * This method is use to get value of getJobCode in EmpWorkerModel POJO class.
	 * 
	 * @return jobCode This parameter is used to set getJobCode.
	 */

	public String getJobCode() {
		return jobCode;
	}

	
	/**
	 * This method is use to set value of jobCode in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param jobCode
	 *            This parameter is used to set jobCode.
	 */
	
	public void setJobCode(String jobCode) {
		this.jobCode = jobCode;
	}

	/**
	 * This method is use to get value of getLocationCode in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return locationCode This parameter is used to set getLocationCode.
	 */

	public String getLocationCode() {
		return locationCode;
	}

	/**
	 * This method is use to set value of locationCode in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param locationCode
	 *            This parameter is used to set locationCode.
	 */
	
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	/**
	 * This method is use to get value of getDepartmentName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return departmentName This parameter is used to set getDepartmentName.
	 */

	public String getDepartmentName() {
		return departmentName;
	}

	/**
	 * This method is use to set value of departmentName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param departmentName
	 *            This parameter is used to set departmentName.
	 */
	
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	/**
	 * This method is use to get value of getLegalEmployerName in EmpWorkerModel
	 * POJO class.
	 * 
	 * @return legalEmployerName This parameter is used to set getLegalEmployerName.
	 */

	public String getLegalEmployerName() {
		return legalEmployerName;
	}
	
	
	/**
	 * This method is use to set value of legalEmployerName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param legalEmployerName
	 *            This parameter is used to set legalEmployerName.
	 */
	

	public void setLegalEmployerName(String legalEmployerName) {
		this.legalEmployerName = legalEmployerName;
	}

	/**
	 * This method is use to get value of getAssignmentStatusType in EmpWorkerModel
	 * POJO class.
	 * 
	 * @return assignmentStatusType This parameter is used to set
	 *         getAssignmentStatusType.
	 */

	public int getAssignmentStatusType() {
		return assignmentStatusType;
	}

	
	/**
	 * This method is use to set value of assignmentStatusType in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param assignmentStatusType
	 *            This parameter is used to set assignmentStatusType.
	 */
	
	
	public void setAssignmentStatusType(int assignmentStatusType) {
		this.assignmentStatusType = assignmentStatusType;
	}

	/**
	 * This method is use to get value of getProjectedStartDate in EmpWorkerModel
	 * POJO class.
	 * 
	 * @return projectedStartDate This parameter is used to set
	 *         getProjectedStartDate.
	 */

	public String getProjectedStartDate() {
		return projectedStartDate;
	}

	/**
	 * This method is use to set value of projectedStartDate in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param projectedStartDate
	 *            This parameter is used to set projectedStartDate.
	 */
	
	public void setProjectedStartDate(String projectedStartDate) {
		if (projectedStartDate.isEmpty() || projectedStartDate == "")
			projectedStartDate = null;
		this.projectedStartDate = projectedStartDate;
	}

	/**
	 * This method is use to get value of getManagerAssignmentId in EmpWorkerModel
	 * POJO class.
	 * 
	 * @return managerAssignmentId This parameter is used to set
	 *         getManagerAssignmentId.
	 */

	public String getManagerAssignmentId() {
		return managerAssignmentId;
	}

	/**
	 * This method is use to set value of managerAssignmentId in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param managerAssignmentId
	 *            This parameter is used to set managerAssignmentId.
	 */
	
	public void setManagerAssignmentId(String managerAssignmentId) {
		this.managerAssignmentId = managerAssignmentId;
	}

	/**
	 * This method is use to get value of getAssignmentId in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return assignmentId This parameter is used to set getAssignmentId.
	 */

	public String getAssignmentId() {
		return assignmentId;
	}

	
	/**
	 * This method is use to set value of assignmentId in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param assignmentId
	 *            This parameter is used to set assignmentId.
	 */
	
	public void setAssignmentId(String assignmentId) {
		this.assignmentId = assignmentId;
	}

	/**
	 * This method is use to get value of getLocationId in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return locationId This parameter is used to set getLocationId.
	 */

	public String getLocationId() {
		return locationId;
	}

	/**
	 * This method is use to set value of locationId in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param locationId
	 *            This parameter is used to set locationId.
	 */
	
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	/**
	 * This method is use to get value of getWorkAtHomeFlag in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return workAtHomeFlag This parameter is used to set getWorkAtHomeFlag.
	 */

	public String getWorkAtHomeFlag() {
		return workAtHomeFlag;
	}

	/**
	 * This method is use to set value of workAtHomeFlag in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param workAtHomeFlag
	 *            This parameter is used to set workAtHomeFlag.
	 */
	
	public void setWorkAtHomeFlag(String workAtHomeFlag) {
		this.workAtHomeFlag = workAtHomeFlag;
	}

	/**
	 * This method is use to get value of getActionCode in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return actionCode This parameter is used to set getActionCode.
	 */

	public String getActionCode() {
		return actionCode;
	}

	
	/**
	 * This method is use to set value of actionCode in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param actionCode
	 *            This parameter is used to set actionCode.
	 */
	
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	/**
	 * This method is use to get value of getFirstName in EmpWorkerModel POJO class.
	 * 
	 * @return firstName This parameter is used to set getFirstName.
	 */

	public String getFirstName() {
		return firstName;
	}

	
	/**
	 * This method is use to set value of firstName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param firstName
	 *            This parameter is used to set firstName.
	 */
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * This method is use to get value of getMiddleName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return middleName This parameter is used to set getMiddleName.
	 */

	public String getMiddleName() {
		return middleName;
	}
	
	

	/**
	 * This method is use to set value of middleName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param middleName
	 *            This parameter is used to set middleName.
	 */

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * This method is use to get value of getLastName in EmpWorkerModel POJO class.
	 * 
	 * @return lastName This parameter is used to set getLastName.
	 */

	public String getLastName() {
		return lastName;
	}

	/**
	 * This method is use to set value of lastName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param lastName
	 *            This parameter is used to set lastName.
	 */
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * This method is use to get value of getDisplayName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return displayName This parameter is used to set getDisplayName.
	 */

	public String getDisplayName() {
		return displayName;
	}
	
	/**
	 * This method is use to set value of displayName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param displayName
	 *            This parameter is used to set displayName.
	 */
	

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * This method is use to get value of getPreferredName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return preferredName This parameter is used to set getPreferredName.
	 */

	public String getPreferredName() {
		return preferredName;
	}

	/**
	 * This method is use to set value of preferredName in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param preferredName
	 *            This parameter is used to set preferredName.
	 */
	
	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	/**
	 * This method is use to get value of getPersonNumber in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return personNumber This parameter is used to set getPersonNumber.
	 */

	public String getPersonNumber() {
		return personNumber;
	}

	
	/**
	 * This method is use to set value of personNumber in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param personNumber
	 *            This parameter is used to set personNumber.
	 */
	public void setPersonNumber(String personNumber) {
		this.personNumber = personNumber;
	}

	/**
	 * This method is use to get value of getHireDate in EmpWorkerModel POJO class.
	 * 
	 * @return hireDate This parameter is used to set getHireDate.
	 */

	public String getHireDate() {
		return hireDate;
	}

	
	/**
	 * This method is use to set value of hireDate in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param hireDate
	 *            This parameter is used to set hireDate.
	 */
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}

	/**
	 * This method is use to get value of getTerminationDate in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return terminationDate This parameter is used to set getTerminationDate.
	 */

	public String getTerminationDate() {

		return terminationDate;
	}
	
	
	/**
	 * This method is use to set value of terminationDate in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param terminationDate
	 *            This parameter is used to set terminationDate.
	 */
	

	public void setTerminationDate(String terminationDate) {
		if (terminationDate.isEmpty() || terminationDate == "")
			terminationDate = null;
		this.terminationDate = terminationDate;
	}

	/**
	 * This method is use to get value of getWorkerType in EmpWorkerModel POJO
	 * class.
	 * 
	 * @return workerType This parameter is used to set getWorkerType.
	 */

	public String getWorkerType() {
		return workerType;
	}

	/**
	 * This method is use to set value of workerType in EmpWorkerModel POJO
	 * class.
	 * 
	 * @param workerType
	 *            This parameter is used to set workerType.
	 */
	public void setWorkerType(String workerType) {

		if (workerType.equalsIgnoreCase("E")) {
			this.workerType = "Employee";
		} else if (workerType.equalsIgnoreCase("P")) {
			this.workerType = "Pending worker";
		} else if (workerType.equalsIgnoreCase("C")) {
			this.workerType = "Contingent worker";
		} else {
			this.workerType = workerType;
		}
	}

}
