package com.kpmg.hcmatom;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.apache.http.HttpEntity;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.kpmg.hcmatom.constants.Constants;
import com.kpmg.hcmatom.usermodel.EmpWorkerModel;
import com.kpmg.hcmatom.usermodel.HCMConfigModel;

/**
 * This class is use to fetch data from Employee and Worker API.
 * 
 * @author ajinkyachavan
 *
 */
public class ReadEmpWorkerRecord {

	private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	// Declare employee record attributes
	public String personNumber;

	public String workerType;

	// Declare Atom feed fields

	public String atomfeed_effectiveDate;
	public String operation;
	public String personName;

	public Date actualTermDate = null;

	// Employee and Worker List to store all employee and worker record.
	List<EmpWorkerModel> list = new ArrayList<>();

	/**
	 * @param employeeRecordCollectionList This field is used to store atom feed
	 *                                     data.
	 * @param getHcmConfig                 This parameter is used to get employee
	 *                                     and worker API configuration values.
	 * @return This method return list of EmpWorkerModel POJO
	 * @throws Exception Throws high level exception occurred in this class while
	 *                   executing custom code.
	 */
	/*
	 * readEmpRecord method is version 2 of the existing logic. As EMP URL is
	 * deprecated, retrieving those user attributes from Worker API itself.
	 */
	public List<EmpWorkerModel> readEmpRecord(HashMap<String, List<String>> employeeRecordCollectionList,
			HCMConfigModel getHcmConfig) throws Exception {
		String METHOD_NAME = "ReadEmpWorkerRecord/readEmpRecord() ";

		try {
			LOGGER.info("Entered " + METHOD_NAME);

			LOGGER.info(METHOD_NAME + " employeeRecordCollectionList " + employeeRecordCollectionList + " getHcmConfig "
					+ getHcmConfig);

			// current date
			LocalDate today = LocalDate.now();
			String actualTerminateDate;

			LOGGER.info("Todays Date :: " + today);

			// adding Effective future hire date
			LocalDate effectiveDate = today.plusDays(Long.parseLong(getHcmConfig.getFutureDate()));

			// Effective Start date
			LOGGER.info("Effective Date :: " + effectiveDate);
			HttpGet request = null;
			HttpGet workerRequest = null;

			// Get Encrypted Key
			String encryptedKey = getHcmConfig.getEncryptKey();

			// Decrypting Password
			Decryption decrypt = new Decryption();
			String password = decrypt.passwordDecrypt(encryptedKey);

			CloseableHttpResponse response;

			// Set Authentication and Authorization
			CredentialsProvider provider = new BasicCredentialsProvider();
			provider.setCredentials(AuthScope.ANY,
					new UsernamePasswordCredentials(getHcmConfig.getUserName(), password));

			int totalRecord = 1;

			// Congfigure Oracle HCM connection timeout.
			int timeout = Constants.CONNECTION_TIMEOUT;
			RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
					.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();

			// Build http client
			try (CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultCredentialsProvider(provider)
					.setDefaultRequestConfig(config).build()) {

				// Check if map is empty
				if (!employeeRecordCollectionList.isEmpty() && employeeRecordCollectionList != null) {

					// Read atom feed map for new hire, emp update and terminate
					for (Map.Entry<String, List<String>> empRecord : employeeRecordCollectionList.entrySet()) {

						// Get entry record from empRecord list
						List<String> val = empRecord.getValue();
						personName = val.get(0);
						atomfeed_effectiveDate = val.get(1);
						operation = val.get(2);
						actualTerminateDate = val.get(3);

						SimpleDateFormat sdf = new SimpleDateFormat(Constants.SIMPLE_DATE_FORMAT);

						if (actualTerminateDate != null && !actualTerminateDate.isEmpty()) {
							actualTermDate = sdf.parse(actualTerminateDate);

						}

						LOGGER.info(
								"######################################################################################################");
						LOGGER.info("# Number of record processing ::" + totalRecord + ":: Total size to process ::"
								+ employeeRecordCollectionList.size());
						LOGGER.info(
								"######################################################################################################");

						totalRecord++;

						EmpWorkerModel emp = new EmpWorkerModel();

						//System.out.println(METHOD_NAME + "############ Calling Employee API for " + empRecord.getKey()
						//		+ " ::  " + empRecord.getValue() + " ############");

						personNumber = (String) empRecord.getKey();

						/*
						 * if (operation.equals(Constants.TERMINATION)) {
						 * 
						 * System.out.println(METHOD_NAME + "Terminated URL created :: " +
						 * getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() + personNumber);
						 * request = new HttpGet(getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() +
						 * personNumber);
						 * 
						 * }
						 * 
						 * else if (operation.equals(Constants.EMP_UPDATE) ||
						 * operation.equals(Constants.EMP_ASSIGNMENT)) {
						 * 
						 * System.out.println(METHOD_NAME + "Creating URL for " + operation + " :: " +
						 * getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() + personNumber);
						 * 
						 * request = new HttpGet(getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() +
						 * personNumber);
						 * 
						 * 
						 * } else { // Construct URL for Employee
						 * 
						 * System.out.println(METHOD_NAME + "Creating URL for " + operation + " :: " +
						 * getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() + personNumber +
						 * Constants.URL_EFFECTIVE_DATE + effectiveDate);
						 * 
						 * request = new HttpGet(getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() +
						 * personNumber + Constants.URL_EFFECTIVE_DATE + effectiveDate);
						 * emp.setFutureTermHireDate(Constants.FALSE);
						 * 
						 * }
						 * 
						 * System.out.println("request.getURI()::"+request.getURI()); // Get response
						 * for individual employee record response = httpClient.execute(request);
						 * 
						 * 
						 * if (response.getStatusLine().getStatusCode() != 200) {
						 * 
						 * throw new Exception("Employee API :: " + response); }
						 * 
						 * 
						 * System.out.println(METHOD_NAME + "Employee api ::" + response);
						 * 
						 * 
						 * if (response != null && response.getStatusLine() != null &&
						 * response.getStatusLine().getStatusCode() == 200) { // Get Employee Details
						 * emp = readEmployeeRecord(response, emp); }
						 */

							LOGGER.info("############ Calling Worker API for " + empRecord.getKey() + " ::  "
									+ empRecord.getValue() + " ############");

						///////////////////// Construct Worker API URL//////////////////////////

						if (operation.equals(Constants.TERMINATION)) {

								LOGGER.info("Creating URL for " + operation + " :: " + getHcmConfig.getBaseUrl()
										+ getHcmConfig.getWorkerUrl() + personNumber);

							workerRequest = new HttpGet(
									getHcmConfig.getBaseUrl() + getHcmConfig.getWorkerUrl() + personNumber);

						}

						else if (operation.equals(Constants.EMP_UPDATE) || operation.equals(Constants.EMP_ASSIGNMENT)) {

								LOGGER.info("Creating URL for " + operation + " :: " + getHcmConfig.getBaseUrl()
										+ getHcmConfig.getWorkerUrl() + personNumber);

							workerRequest = new HttpGet(
									getHcmConfig.getBaseUrl() + getHcmConfig.getWorkerUrl() + personNumber);

						}

						else {

								LOGGER.info("Creating URL for " + operation + " :: " + getHcmConfig.getBaseUrl()
										+ getHcmConfig.getWorkerUrl() + personNumber + Constants.URL_EFFECTIVE_DATE
										+ effectiveDate);

							workerRequest = new HttpGet(getHcmConfig.getBaseUrl() + getHcmConfig.getWorkerUrl()
									+ personNumber + Constants.URL_EFFECTIVE_DATE + effectiveDate);
							emp.setFutureTermHireDate(Constants.FALSE);
						}

						response = httpClient.execute(workerRequest);

						if (response.getStatusLine().getStatusCode() != 200) {

							throw new Exception("Worker API response code :: " + response);
						}

						// Check if Employee worker is 200 then call Worker API
						if (response != null && response.getStatusLine() != null
								&& response.getStatusLine().getStatusCode() == 200) {
								LOGGER.info("Worker api ::" + response);

							// Read worker record
							emp = readWorkerRecord(response, emp);
							try {
								if (!emp.getPersonNumber().isEmpty() && emp.getPersonNumber() != null) {

									list.add(emp);

										LOGGER.info("Complete Record from Empl and Worker" + emp.toString());
									}

							} catch (Exception e) {
									LOGGER.info("Skipping record as there is no data");
							}

						} else {
								LOGGER.info("Worker API call is not successed");
						}

					}

				} else {
					LOGGER.info("######## No record into atom feed record########");
				}
			} catch (Exception e) {
				throw new Error(e);
			}

		}

		catch (Exception e) {

			e.printStackTrace();
			throw e;
		}

		finally {

			LOGGER.info("#### Exiting from ReadEmpWorkerRecord Class ####");
			LOGGER.info("Exit " + METHOD_NAME);
		}
		return list;
	}
	/*
	 * Backup of the readEmpRecord method version 1 public List<EmpWorkerModel>
	 * readEmpRecord(HashMap<String, List<String>> employeeRecordCollectionList,
	 * HCMConfigModel getHcmConfig) throws Exception { String METHOD_NAME =
	 * "ReadEmpWorkerRecord/readEmpRecord() ";
	 * 
	 * try { System.out.println("Entered " + METHOD_NAME);
	 * 
	 * System.out.println(METHOD_NAME + " employeeRecordCollectionList " +
	 * employeeRecordCollectionList + " getHcmConfig " + getHcmConfig);
	 * 
	 * // current date LocalDate today = LocalDate.now(); String
	 * actualTerminateDate;
	 * 
	 * System.out.println(METHOD_NAME + "Todays Date :: " + today);
	 * 
	 * // adding Effective future hire date LocalDate effectiveDate =
	 * today.plusDays(Long.parseLong(getHcmConfig.getFutureDate()));
	 * 
	 * // Effective Start date System.out.println(METHOD_NAME + "Effective Date :: "
	 * + effectiveDate); HttpGet request = null; HttpGet workerRequest = null;
	 * 
	 * // Get Encrypted Key String encryptedKey = getHcmConfig.getEncryptKey();
	 * 
	 * // Decrypting Password Decryption decrypt = new Decryption(); String password
	 * = decrypt.passwordDecrypt(encryptedKey);
	 * 
	 * CloseableHttpResponse response;
	 * 
	 * // Set Authentication and Authorization CredentialsProvider provider = new
	 * BasicCredentialsProvider(); provider.setCredentials(AuthScope.ANY, new
	 * UsernamePasswordCredentials(getHcmConfig.getUserName(), password));
	 * 
	 * int totalRecord = 1;
	 * 
	 * // Congfigure Oracle HCM connection timeout. int timeout =
	 * Constants.CONNECTION_TIMEOUT; RequestConfig config =
	 * RequestConfig.custom().setConnectTimeout(timeout * 1000)
	 * .setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout *
	 * 1000).build();
	 * 
	 * // Build http client try (CloseableHttpClient httpClient =
	 * HttpClientBuilder.create().setDefaultCredentialsProvider(provider)
	 * .setDefaultRequestConfig(config).build()) {
	 * 
	 * 
	 * 
	 * // Check if map is empty if (!employeeRecordCollectionList.isEmpty() &&
	 * employeeRecordCollectionList != null) {
	 * 
	 * // Read atom feed map for new hire, emp update and terminate for
	 * (Map.Entry<String, List<String>> empRecord :
	 * employeeRecordCollectionList.entrySet()) {
	 * 
	 * // Get entry record from empRecord list List<String> val =
	 * empRecord.getValue(); personName = val.get(0); atomfeed_effectiveDate =
	 * val.get(1); operation = val.get(2); actualTerminateDate = val.get(3);
	 * 
	 * SimpleDateFormat sdf = new SimpleDateFormat(Constants.SIMPLE_DATE_FORMAT);
	 * 
	 * if (actualTerminateDate != null && !actualTerminateDate.isEmpty()) {
	 * actualTermDate = sdf.parse(actualTerminateDate);
	 * 
	 * }
	 * 
	 * System.out.println(METHOD_NAME +
	 * "######################################################################################################"
	 * ); System.out.println(METHOD_NAME + "# Number of record processing ::" +
	 * totalRecord + ":: Total size to process ::" +
	 * employeeRecordCollectionList.size()); System.out.println(METHOD_NAME +
	 * "######################################################################################################"
	 * );
	 * 
	 * totalRecord++;
	 * 
	 * EmpWorkerModel emp = new EmpWorkerModel();
	 * 
	 * System.out.println(METHOD_NAME + "############ Calling Employee API for " +
	 * empRecord.getKey() + " ::  " + empRecord.getValue() + " ############");
	 * 
	 * personNumber = (String) empRecord.getKey();
	 * 
	 * if (operation.equals(Constants.TERMINATION)) {
	 * 
	 * System.out.println(METHOD_NAME + "Terminated URL created :: " +
	 * getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() + personNumber);
	 * request = new HttpGet(getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() +
	 * personNumber);
	 * 
	 * }
	 * 
	 * else if (operation.equals(Constants.EMP_UPDATE) ||
	 * operation.equals(Constants.EMP_ASSIGNMENT)) {
	 * 
	 * System.out.println(METHOD_NAME + "Creating URL for " + operation + " :: " +
	 * getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() + personNumber);
	 * 
	 * request = new HttpGet(getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() +
	 * personNumber);
	 * 
	 * 
	 * } else { // Construct URL for Employee
	 * 
	 * System.out.println(METHOD_NAME + "Creating URL for " + operation + " :: " +
	 * getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() + personNumber +
	 * Constants.URL_EFFECTIVE_DATE + effectiveDate);
	 * 
	 * request = new HttpGet(getHcmConfig.getBaseUrl() + getHcmConfig.getEmpsUrl() +
	 * personNumber + Constants.URL_EFFECTIVE_DATE + effectiveDate);
	 * emp.setFutureTermHireDate(Constants.FALSE);
	 * 
	 * } System.out.println("request.getURI()::"+request.getURI()); // Get response
	 * for individual employee record response = httpClient.execute(request);
	 * 
	 * if (response.getStatusLine().getStatusCode() != 200) {
	 * 
	 * throw new Exception("Employee API :: " + response); }
	 * 
	 * System.out.println(METHOD_NAME + "Employee api ::" + response);
	 * 
	 * if (response != null && response.getStatusLine() != null &&
	 * response.getStatusLine().getStatusCode() == 200) {
	 * 
	 * // Get Employee Details emp = readEmployeeRecord(response, emp);
	 * 
	 * System.out.println(METHOD_NAME + "############ Calling Worker API for " +
	 * empRecord.getKey() + " ::  " + empRecord.getValue() + " ############");
	 * 
	 * ///////////////////// Construct Worker API URL//////////////////////////
	 * 
	 * if (operation.equals(Constants.TERMINATION)) {
	 * 
	 * System.out.println(METHOD_NAME + "Creating URL for " + operation + " :: " +
	 * getHcmConfig.getBaseUrl() + getHcmConfig.getWorkerUrl() + personNumber);
	 * 
	 * workerRequest = new HttpGet( getHcmConfig.getBaseUrl() +
	 * getHcmConfig.getWorkerUrl() + personNumber);
	 * 
	 * }
	 * 
	 * else if (operation.equals(Constants.EMP_UPDATE) ||
	 * operation.equals(Constants.EMP_ASSIGNMENT)) {
	 * 
	 * System.out.println(METHOD_NAME + "Creating URL for " + operation + " :: " +
	 * getHcmConfig.getBaseUrl() + getHcmConfig.getWorkerUrl() + personNumber);
	 * 
	 * workerRequest = new HttpGet( getHcmConfig.getBaseUrl() +
	 * getHcmConfig.getWorkerUrl() + personNumber);
	 * 
	 * }
	 * 
	 * else {
	 * 
	 * System.out.println(METHOD_NAME + "Creating URL for " + operation + " :: " +
	 * getHcmConfig.getBaseUrl() + getHcmConfig.getWorkerUrl() + personNumber +
	 * Constants.URL_EFFECTIVE_DATE + effectiveDate);
	 * 
	 * workerRequest = new HttpGet(getHcmConfig.getBaseUrl() +
	 * getHcmConfig.getWorkerUrl() + personNumber + Constants.URL_EFFECTIVE_DATE +
	 * effectiveDate); emp.setFutureTermHireDate(Constants.FALSE); }
	 * 
	 * response = httpClient.execute(workerRequest);
	 * 
	 * if (response.getStatusLine().getStatusCode() != 200) {
	 * 
	 * throw new Exception("Worker API response code :: " + response); }
	 * 
	 * // Check if Employee worker is 200 then call Worker API if (response != null
	 * && response.getStatusLine() != null &&
	 * response.getStatusLine().getStatusCode() == 200) {
	 * System.out.println(METHOD_NAME + "Worker api ::" + response);
	 * 
	 * // Read worker record emp = readWorkerRecord(response, emp); try { if
	 * (!emp.getPersonNumber().isEmpty() && emp.getPersonNumber() != null) {
	 * 
	 * list.add(emp);
	 * 
	 * System.out.println(METHOD_NAME + "Complete Record from Empl and Worker" +
	 * emp.toString()); }
	 * 
	 * } catch (Exception e) { System.out.println(METHOD_NAME +
	 * "Skipping record as there is no data"); }
	 * 
	 * } else { System.out.println(METHOD_NAME +
	 * "Worker API call is not successed"); } } }
	 * 
	 * } else { System.out.println(METHOD_NAME +
	 * "######## No record into atom feed record########"); } } catch (Exception e)
	 * { throw new Error(e); }
	 * 
	 * }
	 * 
	 * catch (Exception e) {
	 * 
	 * e.printStackTrace(); throw e; }
	 * 
	 * finally {
	 * 
	 * System.out.println(METHOD_NAME +
	 * "#### Exiting from ReadEmpWorkerRecord Class ####");
	 * System.out.println("Exit " + METHOD_NAME); } return list; }
	 */

	/**
	 * This method is used to get values from employee api response and set values
	 * into EmpWorkerModel POJO class.
	 * 
	 * @param response This parameter is use to pass response from employee API to
	 *                 readEmployeeRecord method.
	 * @param emp      This parameter is used to store value that are fetch from emp
	 *                 API into EmpWorkerModel POJO class.
	 * @return This method return emp object of EmpWorkerModel POJO class.
	 * @throws Exception Throws high level exception occurred in this class while
	 *                   executing custom code.
	 */
	/*
	 * EMP URL is deprecated. Attributes retrieved from EMP URL are now available
	 * through Worker API. Hence commenting readEmployeeRecord method and handling
	 * the attributes through readEmployeeRecord method.
	 * 
	 * public EmpWorkerModel readEmployeeRecord(CloseableHttpResponse response,
	 * EmpWorkerModel emp) throws Exception {
	 * 
	 * String METHOD_NAME = "ReadEmpWorkerRecord/readEmployeeRecord() ";
	 * System.out.println("Entered " + METHOD_NAME); System.out.println(METHOD_NAME
	 * + " response " + response + " emp" + emp.toString());
	 * 
	 * // Check if status code is 200 if (response.getStatusLine().getStatusCode()
	 * == 200) {
	 * 
	 * System.out.println(METHOD_NAME + "Emp API reponse code for ::" + personNumber
	 * + " :: " + response.getStatusLine().getStatusCode());
	 * 
	 * HttpEntity entity = response.getEntity();
	 * 
	 * // Check if entity is null if (entity != null) {
	 * 
	 * // return it as a String String result =
	 * EntityUtils.toString(entity,"UTF-8");
	 * 
	 * JSONObject json = new JSONObject(result);
	 * 
	 * // Check total record from API call for single person number int
	 * hasMoreRecord = (int) json.get(Constants.TOTAL_RESULTS);
	 * System.out.println(METHOD_NAME + "Total Result for ::" + personNumber +
	 * " :: " + hasMoreRecord); if (hasMoreRecord != 0) { // Get items into JSON
	 * array list JSONArray items = json.getJSONArray(Constants.ITEMS); Iterator<?>
	 * iterator = items.iterator(); System.out.println(METHOD_NAME +
	 * "Length of items is : " + items.length()); int itemLenght = 0;
	 * 
	 * if (items.length() > 1) {
	 * 
	 * while (iterator.hasNext()) { JSONObject getItem = (JSONObject)
	 * iterator.next();
	 * 
	 * workerType = (String) getItem.get(Constants.WORKER_TYPE);
	 * System.out.println(METHOD_NAME + "Setting Employee Record" + workerType); if
	 * (workerType.equals(Constants.WORKER_TYPE_E)) {
	 * 
	 * System.out.println(METHOD_NAME +
	 * "Setting Employee Record into Employee POJO");
	 * 
	 * emp.setPersonNumber(getItem.isNull(Constants.PERSON_NUMBER) ? "" :
	 * String.valueOf(getItem.get(Constants.PERSON_NUMBER)));
	 * 
	 * emp.setFirstName(getItem.isNull(Constants.FIRST_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.FIRST_NAME)));
	 * 
	 * emp.setMiddleName(getItem.isNull(Constants.MIDDLE_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.MIDDLE_NAME)));
	 * 
	 * emp.setLastName(getItem.isNull(Constants.LAST_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.LAST_NAME)));
	 * 
	 * emp.setDisplayName(getItem.isNull(Constants.DISPLAY_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.DISPLAY_NAME)));
	 * 
	 * emp.setPreferredName(getItem.isNull(Constants.PREFERRED_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.PREFERRED_NAME)));
	 * 
	 * emp.setHireDate(getItem.isNull(Constants.HIRE_DATE) ? "" :
	 * String.valueOf(getItem.get(Constants.HIRE_DATE)));
	 * 
	 * emp.setTerminationDate(getItem.isNull(Constants.TERMINATION_DATE) ? "" :
	 * String.valueOf(getItem.get(Constants.TERMINATION_DATE)));
	 * 
	 * emp.setWorkerType(getItem.isNull(Constants.EMP_WORKER_TYPE) ? "" :
	 * String.valueOf(getItem.get(Constants.EMP_WORKER_TYPE)));
	 * 
	 * emp.setPersonId(getItem.isNull(Constants.PERSON_ID) ? (String) "" :
	 * String.valueOf(getItem.get(Constants.PERSON_ID)));
	 * 
	 * System.out.println(METHOD_NAME + "Person Number ::" + emp.getPersonNumber() +
	 * ", " + "WorkerType ::" + emp.getWorkerType() + ", " + "First Name ::" +
	 * emp.getFirstName() + ", " + "Middle Name ::" + emp.getMiddleName() + "," +
	 * "Last Name ::" + emp.getLastName() + ", " + "Display Name ::" +
	 * emp.getDisplayName() + ", " + "Preffered Name ::" + emp.getPreferredName() +
	 * ", " + "Hire Date ::" + emp.getHireDate() + ", " + "Terminate Date ::" +
	 * emp.getTerminationDate() + ", " + "Person ID ::" + emp.getPersonId());
	 * 
	 * }
	 * 
	 * else { System.out.println(METHOD_NAME +
	 * "Setting Employee Record in Employeee POJO");
	 * 
	 * emp.setPersonNumber(getItem.isNull(Constants.PERSON_NUMBER) ? "" :
	 * String.valueOf(getItem.get(Constants.PERSON_NUMBER)));
	 * 
	 * emp.setFirstName(getItem.isNull(Constants.FIRST_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.FIRST_NAME)));
	 * 
	 * emp.setMiddleName(getItem.isNull(Constants.MIDDLE_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.MIDDLE_NAME)));
	 * 
	 * emp.setLastName(getItem.isNull(Constants.LAST_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.LAST_NAME)));
	 * 
	 * emp.setDisplayName(getItem.isNull(Constants.DISPLAY_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.DISPLAY_NAME)));
	 * 
	 * emp.setPreferredName(getItem.isNull(Constants.PREFERRED_NAME) ? "" :
	 * String.valueOf(getItem.get(Constants.PREFERRED_NAME)));
	 * 
	 * emp.setHireDate(getItem.isNull(Constants.HIRE_DATE) ? "" :
	 * String.valueOf(getItem.get(Constants.HIRE_DATE)));
	 * 
	 * emp.setTerminationDate(getItem.isNull(Constants.TERMINATION_DATE) ? "" :
	 * String.valueOf(getItem.get(Constants.TERMINATION_DATE)));
	 * 
	 * emp.setWorkerType(getItem.isNull(Constants.EMP_WORKER_TYPE) ? "" :
	 * String.valueOf(getItem.get(Constants.EMP_WORKER_TYPE)));
	 * 
	 * emp.setPersonId(getItem.isNull(Constants.PERSON_ID) ? "" :
	 * String.valueOf(getItem.get(Constants.PERSON_ID)));
	 * 
	 * System.out.println(METHOD_NAME + "Person Number ::" + emp.getPersonNumber() +
	 * ", " + "WorkerType ::" + emp.getWorkerType() + ", " + "First Name ::" +
	 * emp.getFirstName() + ", " + "Middle Name ::" + emp.getMiddleName() + "," +
	 * "Last Name ::" + emp.getLastName() + ", " + "Display Name ::" +
	 * emp.getDisplayName() + ", " + "Preffered Name ::" + emp.getPreferredName() +
	 * ", " + "Hire Date ::" + emp.getHireDate() + ", " + "Terminate Date ::" +
	 * emp.getTerminationDate() + ", " + "Person ID ::" + emp.getPersonId());
	 * 
	 * }
	 * 
	 * break; }
	 * 
	 * System.out.println(METHOD_NAME +
	 * "###############################################");
	 * 
	 * }
	 * 
	 * else if (items.length() != 0) {
	 * 
	 * System.out.println(METHOD_NAME +
	 * "Setting Employee Record in Employeee POJO");
	 * 
	 * emp.setFirstName(items.getJSONObject(itemLenght).isNull(Constants.FIRST_NAME)
	 * ? "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.FIRST_NAME)));
	 * 
	 * emp.setMiddleName(items.getJSONObject(itemLenght).isNull(Constants.
	 * MIDDLE_NAME) ? "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.MIDDLE_NAME)));
	 * 
	 * emp.setLastName(items.getJSONObject(itemLenght).isNull(Constants.LAST_NAME) ?
	 * "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.LAST_NAME)));
	 * 
	 * emp.setDisplayName(items.getJSONObject(itemLenght).isNull(Constants.
	 * DISPLAY_NAME) ? "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.DISPLAY_NAME)));
	 * 
	 * emp.setPreferredName(items.getJSONObject(itemLenght).isNull(Constants.
	 * PREFERRED_NAME) ? "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.PREFERRED_NAME))
	 * );
	 * 
	 * emp.setPersonNumber(items.getJSONObject(itemLenght).isNull(Constants.
	 * PERSON_NUMBER) ? "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.PERSON_NUMBER)))
	 * ;
	 * 
	 * emp.setHireDate(items.getJSONObject(itemLenght).isNull(Constants.HIRE_DATE) ?
	 * "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.HIRE_DATE)));
	 * 
	 * emp.setTerminationDate(items.getJSONObject(itemLenght).isNull(Constants.
	 * TERMINATION_DATE) ? "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.TERMINATION_DATE
	 * )));
	 * 
	 * emp.setWorkerType(items.getJSONObject(itemLenght).isNull(Constants.
	 * EMP_WORKER_TYPE) ? "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.EMP_WORKER_TYPE)
	 * ));
	 * 
	 * emp.setPersonId(items.getJSONObject(itemLenght).isNull(Constants.PERSON_ID) ?
	 * "" :
	 * String.valueOf(items.getJSONObject(itemLenght).get(Constants.PERSON_ID)));
	 * 
	 * System.out.println(METHOD_NAME + "Person Number ::" + emp.getPersonNumber() +
	 * ", " + "WorkerType ::" + emp.getWorkerType() + ", " + "First Name ::" +
	 * emp.getFirstName() + ", " + "Middle Name ::" + emp.getMiddleName() + "," +
	 * "Last Name ::" + emp.getLastName() + ", " + "Display Name ::" +
	 * emp.getDisplayName() + ", " + "Preffered Name ::" + emp.getPreferredName() +
	 * ", " + "Hire Date ::" + emp.getHireDate() + ", " + "Terminate Date ::" +
	 * emp.getTerminationDate() + ", " + "Person ID ::" + emp.getPersonId()); } }
	 * 
	 * else {
	 * 
	 * System.out.println(METHOD_NAME + "No record found for Employee API :: " +
	 * personNumber); }
	 * 
	 * } } System.out.println("Exit " + METHOD_NAME); return emp; }
	 */
	/**
	 * This method is used to get values from worker API response and set values
	 * into EmpWorkerModel POJO class.
	 * 
	 * @param response This parameter is use to pass response from employee API to
	 *                 readEmployeeRecord method.
	 * @param emp      This parameter is used to store value that are fetch from
	 *                 worker API into EmpWorkerModel POJO class.
	 * @return This method return emp object of EmpWorkerModel POJO class.
	 * @throws Exception Throws high level exception occurred in this class while
	 *                   executing custom code.
	 */
	private EmpWorkerModel readWorkerRecord(CloseableHttpResponse workerResponse, EmpWorkerModel emp) throws Exception {

		String METHOD_NAME = "ReadEmpWorkerRecord/readWorkerRecord() ";

		try {
			LOGGER.info("Entered " + METHOD_NAME);
			LOGGER.info(METHOD_NAME + " response " + workerResponse + " emp" + emp.toString());
			
			SimpleDateFormat sdf = new SimpleDateFormat(Constants.SIMPLE_DATE_FORMAT);

			// Check if Worker API response code is 200
			if (workerResponse.getStatusLine().getStatusCode() == 200) {

				LOGGER.info("Worker api reponse code for ::" + personNumber + " :: "
						+ workerResponse.getStatusLine().getStatusCode());

				HttpEntity entity = workerResponse.getEntity();

				// return it as a String
				String result = EntityUtils.toString(entity, "UTF-8");

				// Convert Entity Object result into JSON object
				JSONObject json = new JSONObject(result);
				// Check total record from api call for single person number int
				int hasMoreRecord = (int) json.get("totalResults");

				LOGGER.info("Total Result in Worker API for ::" + personNumber + " :: " + hasMoreRecord);

				if (hasMoreRecord != 0) {

					// Get items into JSON array list
					JSONArray items = json.getJSONArray(Constants.ITEMS);
					int itemLenght = 0;
					
					/*
					 * Below Code Added During Emp URL to Worker URL conversion change request
					 * ----------------------------------------------------------------------- 
					 */
					emp.setPersonId(
							items.getJSONObject(itemLenght).isNull(Constants.PERSON_ID) ? ""
									: String.valueOf(items.getJSONObject(itemLenght)
											.get(Constants.PERSON_ID)));
					emp.setPersonNumber(
							items.getJSONObject(itemLenght).isNull(Constants.PERSON_NUMBER) ? ""
									: String.valueOf(items.getJSONObject(itemLenght)
											.get(Constants.PERSON_NUMBER)));
					JSONArray names = items.getJSONObject(0).getJSONArray(Constants.NAMES);
					if (names.length() == 1) {
						emp.setFirstName(
								names.getJSONObject(itemLenght).isNull(Constants.FIRST_NAME) ? ""
										: String.valueOf(names.getJSONObject(itemLenght)
												.get(Constants.FIRST_NAME)));
						emp.setMiddleName(
								names.getJSONObject(itemLenght).isNull(Constants.MIDDLE_NAME) ? ""
										: String.valueOf(names.getJSONObject(itemLenght)
												.get(Constants.MIDDLE_NAME)));
						emp.setLastName(
								names.getJSONObject(itemLenght).isNull(Constants.LAST_NAME) ? ""
										: String.valueOf(names.getJSONObject(itemLenght)
												.get(Constants.LAST_NAME)));
						emp.setDisplayName(
								names.getJSONObject(itemLenght).isNull(Constants.DISPLAY_NAME) ? ""
										: String.valueOf(names.getJSONObject(itemLenght)
												.get(Constants.DISPLAY_NAME)));
						emp.setPreferredName(
								names.getJSONObject(itemLenght).isNull(Constants.PREFERRED_NAME) ? ""
										: String.valueOf(names.getJSONObject(itemLenght)
												.get(Constants.PREFERRED_NAME)));
						
					}
					/*
					 * Above Code Added During Emp URL to Worker URL conversion change request
					 * ----------------------------------------------------------------------- 
					 */
					JSONArray workRelationships = items.getJSONObject(0).getJSONArray(Constants.WORK_RELATION_SHIPS);

					LOGGER.info("Length of items in worker is : " + workRelationships.length());

					
					if (workRelationships.length() == 1) {
						/*
						 * Below Code Added During Emp URL to Worker URL conversion change request
						 * ----------------------------------------------------------------------- 
						 */
						emp.setHireDate(
								workRelationships.getJSONObject(itemLenght).isNull(Constants.HIRE_DATE) ? ""
										: String.valueOf(workRelationships.getJSONObject(itemLenght)
												.get(Constants.HIRE_DATE)));
						emp.setTerminationDate(
								workRelationships.getJSONObject(itemLenght).isNull(Constants.TERMINATION_DATE) ? ""
										: String.valueOf(workRelationships.getJSONObject(itemLenght)
												.get(Constants.TERMINATION_DATE)));
						/*
						 * Above Code Added During Emp URL to Worker URL conversion change request
						 * ----------------------------------------------------------------------- 
						 */
						emp.setLegalEmployerName(
								workRelationships.getJSONObject(itemLenght).isNull(Constants.LEGALEMPLOYER_NAME) ? ""
										: String.valueOf(workRelationships.getJSONObject(itemLenght)
												.get(Constants.LEGALEMPLOYER_NAME)));

						emp.setWorkerType(workRelationships.getJSONObject(itemLenght).isNull(Constants.WORKER_TYPE) ? ""
								: String.valueOf(
										workRelationships.getJSONObject(itemLenght).get(Constants.WORKER_TYPE)));

						JSONArray assignmentItem = workRelationships.getJSONObject(itemLenght)
								.getJSONArray(Constants.ASSIGNMENTS);

						if (assignmentItem != null && assignmentItem.length() > 0) {
							emp.setJobCode(assignmentItem.getJSONObject(itemLenght).isNull(Constants.JOB_CODE) ? ""
									: String.valueOf(assignmentItem.getJSONObject(itemLenght).get(Constants.JOB_CODE)));

							emp.setLocationCode(assignmentItem.getJSONObject(itemLenght).isNull(Constants.LOCATION_CODE)
									? ""
									: String.valueOf(
											assignmentItem.getJSONObject(itemLenght).get(Constants.LOCATION_CODE)));

							emp.setDepartmentName(
									assignmentItem.getJSONObject(itemLenght).isNull(Constants.DEPARTMENT_NAME) ? ""
											: String.valueOf(assignmentItem.getJSONObject(itemLenght)
													.get(Constants.DEPARTMENT_NAME)));

							/*
							 * Below Code Added to pull GradeId from Worker URL conversion change request
							 * ----------------------------------------------------------------------- 
							 */
							emp.setGradeId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.GRADE_ID) ? ""
									: String.valueOf(assignmentItem.getJSONObject(itemLenght)
											.get(Constants.GRADE_ID)));
							/*
							 * Above Code Added to pull GradeId from Worker URL conversion change request
							 * ----------------------------------------------------------------------- 
							 */
							String status = (String) assignmentItem.getJSONObject(itemLenght)
									.get(Constants.ASSIGNMENT_STATUS_TYPE);
							int statuskey;
							if (status.equalsIgnoreCase(Constants.ACTIVE))
								statuskey = 1;
							else
								statuskey = 0;

							// Set Status for employee
							emp.setAssignmentStatusType(statuskey);

							emp.setLocationId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.LOCATION_ID)
									? ""
									: String.valueOf(
											assignmentItem.getJSONObject(itemLenght).get(Constants.LOCATION_ID)));

							emp.setAssignmentId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.ASSIGNMENT_ID)
									? ""
									: String.valueOf(
											assignmentItem.getJSONObject(itemLenght).get(Constants.ASSIGNMENT_ID)));

							emp.setActionCode(assignmentItem.getJSONObject(itemLenght).isNull(Constants.ACTION_CODE)
									? ""
									: String.valueOf(
											assignmentItem.getJSONObject(itemLenght).get(Constants.ACTION_CODE)));

							emp.setWorkAtHomeFlag(
									assignmentItem.getJSONObject(itemLenght).isNull(Constants.WORK_AT_HOME_FLAG) ? ""
											: String.valueOf(assignmentItem.getJSONObject(itemLenght)
													.get(Constants.WORK_AT_HOME_FLAG)));
							emp.setUserPersonType(
									assignmentItem.getJSONObject(itemLenght).isNull(Constants.USER_PERSON_TYPE) ? ""
											: String.valueOf(assignmentItem.getJSONObject(itemLenght)
													.get(Constants.USER_PERSON_TYPE)));

							emp.setPositionId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.POSITION_ID)
									? ""
									: String.valueOf(
											assignmentItem.getJSONObject(itemLenght).get(Constants.POSITION_ID)));

							emp.setNormalHours(assignmentItem.getJSONObject(itemLenght).isNull(Constants.NORMAL_HOURS)
									? ""
									: String.valueOf(
											assignmentItem.getJSONObject(itemLenght).get(Constants.NORMAL_HOURS)));

							emp.setFrequency(assignmentItem.getJSONObject(itemLenght).isNull(Constants.FREQUENCY) ? ""
									: String.valueOf(
											assignmentItem.getJSONObject(itemLenght).get(Constants.FREQUENCY)));

							// Transformation is calculated into EmplWorkerModel.java class
							emp.setAssignmentCategory(
									assignmentItem.getJSONObject(itemLenght).isNull(Constants.ASSIGNMENT_CATEGORY) ? ""
											: String.valueOf(assignmentItem.getJSONObject(itemLenght)
													.get(Constants.ASSIGNMENT_CATEGORY)));

							// Calculate Start date for Pending Worker

							if (Constants.PENDING_WORKER.compareToIgnoreCase(emp.getWorkerType()) == 0) {

								emp.setProjectedStartDate(
										assignmentItem.getJSONObject(itemLenght).isNull(Constants.PROJECTED_START_DATE)
												? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.PROJECTED_START_DATE)));

							} else {

								emp.setProjectedStartDate(emp.getHireDate());
							}

							// Set Pay Group Attribute
							emp.setPeopleGroup(assignmentItem.getJSONObject(itemLenght).isNull(Constants.PEOPLE_GROUP)
									? ""
									: String.valueOf(
											assignmentItem.getJSONObject(itemLenght).get(Constants.PEOPLE_GROUP)));

							// Get Line Manager Assignment ID

							JSONArray managerItem = assignmentItem.getJSONObject(itemLenght)
									.getJSONArray(Constants.MANAGERS);

							if (managerItem != null && managerItem.length() != 0) {

								setLineManager(emp, managerItem);
							} else {
								emp.setManagerAssignmentId("");
							}

							// Check Employee type for Active Directory

							JSONArray assignmentsDFFItem = assignmentItem.getJSONObject(itemLenght)
									.getJSONArray(Constants.ASSIGNMENTS_DFF);

							if (assignmentsDFFItem != null && assignmentsDFFItem.length() != 0) {
								emp.setPayRule(assignmentsDFFItem.getJSONObject(itemLenght).isNull(Constants.PAY_RULE)
										? ""
										: String.valueOf(
												assignmentsDFFItem.getJSONObject(itemLenght).get(Constants.PAY_RULE)));
							} else {
								emp.setPayRule("");
							}

						}

						LOGGER.info("Completed User Record ::" + emp.toString());

					} else {

						LOGGER.info("There are multiple assignemnt for record ::" + emp.getPersonNumber());
						HashMap<String, String> workerRelationRecord = new HashMap<String, String>();
						

                        Boolean activeFlag = false;
                        Date latestStartDate = null ;
                        String latestServiceID = null ;
						Date startDate;
						LocalDate today = LocalDate.now();
						Date currentDate = sdf.parse(today.toString());
						for (int i = 0; i < workRelationships.length(); i++) {

							workRelationships = items.getJSONObject(itemLenght)
									.getJSONArray(Constants.WORK_RELATION_SHIPS);

							/*
							 * Below Code Added During Emp URL to Worker URL conversion change request
							 * ----------------------------------------------------------------------- 
							 */
							emp.setHireDate(
									workRelationships.getJSONObject(i).isNull(Constants.HIRE_DATE) ? ""
											: String.valueOf(workRelationships.getJSONObject(i)
													.get(Constants.HIRE_DATE)));
							emp.setTerminationDate(
									workRelationships.getJSONObject(i).isNull(Constants.TERMINATION_DATE) ? ""
											: String.valueOf(workRelationships.getJSONObject(i)
													.get(Constants.TERMINATION_DATE)));
							
							
							/*
							 * Above Code Added During Emp URL to Worker URL conversion change request
							 * ----------------------------------------------------------------------- 
							 */
							
							emp.setLegalEmployerName(
									workRelationships.getJSONObject(i).isNull(Constants.LEGALEMPLOYER_NAME) ? ""
											: String.valueOf(workRelationships.getJSONObject(i)
													.get(Constants.LEGALEMPLOYER_NAME)));

							emp.setWorkerType(workRelationships.getJSONObject(i).isNull(Constants.WORKER_TYPE) ? ""
									: String.valueOf(workRelationships.getJSONObject(i).get(Constants.WORKER_TYPE)));

							JSONArray assignmentItem = workRelationships.getJSONObject(i)
									.getJSONArray(Constants.ASSIGNMENTS);

							if (assignmentItem != null && assignmentItem.length() > 0) {
								/*
								 * Below Code Added to pull GradeId from Worker URL conversion change request
								 * ----------------------------------------------------------------------- 
								 */
								emp.setGradeId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.GRADE_ID) ? ""
										: String.valueOf(assignmentItem.getJSONObject(itemLenght)
												.get(Constants.GRADE_ID)));
								/*
								 * Above Code Added to pull GradeId from Worker URL conversion change request
								 * ----------------------------------------------------------------------- 
								 */
								emp.setJobCode(assignmentItem.getJSONObject(itemLenght).isNull(Constants.JOB_CODE) ? ""
										: String.valueOf(
												assignmentItem.getJSONObject(itemLenght).get(Constants.JOB_CODE)));

								emp.setLocationCode(
										assignmentItem.getJSONObject(itemLenght).isNull(Constants.LOCATION_CODE) ? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.LOCATION_CODE)));

								emp.setDepartmentName(
										assignmentItem.getJSONObject(itemLenght).isNull(Constants.DEPARTMENT_NAME) ? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.DEPARTMENT_NAME)));

								String status = String.valueOf(
										assignmentItem.getJSONObject(itemLenght).get(Constants.ASSIGNMENT_STATUS_TYPE));
								int statuskey;
								if (status.equalsIgnoreCase(Constants.ACTIVE)) {
									statuskey = 1;									
								}else {
									statuskey = 0;
									workerRelationRecord.put(workRelationships.getJSONObject(i).isNull(
											Constants.PERIODOFSERVICEID) ? "" : String.valueOf(
													workRelationships.getJSONObject(i).get(Constants.PERIODOFSERVICEID)), workRelationships.getJSONObject(i).isNull(Constants.HIRE_DATE) ? ""
															: String.valueOf(workRelationships.getJSONObject(i)
																	.get(Constants.HIRE_DATE)));
									
									if (emp.getHireDate() != null && latestStartDate == null) {
								    	latestStartDate=sdf.parse(emp.getHireDate());
								    	latestServiceID= workRelationships.getJSONObject(i).isNull(
												Constants.PERIODOFSERVICEID) ? "" : String.valueOf(
														workRelationships.getJSONObject(i).get(Constants.PERIODOFSERVICEID));
								    } else if (emp.getHireDate() != null){
								    	 startDate =sdf.parse(emp.getHireDate());
								    	 if (startDate.after(latestStartDate) && startDate.before(currentDate)) {
								    		 latestStartDate = startDate;
								    		 latestServiceID= workRelationships.getJSONObject(i).isNull(
														Constants.PERIODOFSERVICEID) ? "" : String.valueOf(
																workRelationships.getJSONObject(i).get(Constants.PERIODOFSERVICEID));
								    	 }
								    }

									
									
									
								}
								// Set Status for employee
								emp.setAssignmentStatusType(statuskey);

								emp.setLocationId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.LOCATION_ID)
										? ""
										: String.valueOf(
												assignmentItem.getJSONObject(itemLenght).get(Constants.LOCATION_ID)));

								emp.setAssignmentId(
										assignmentItem.getJSONObject(itemLenght).isNull(Constants.ASSIGNMENT_ID) ? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.ASSIGNMENT_ID)));

								emp.setActionCode(assignmentItem.getJSONObject(itemLenght).isNull(Constants.ACTION_CODE)
										? ""
										: String.valueOf(
												assignmentItem.getJSONObject(itemLenght).get(Constants.ACTION_CODE)));

								emp.setWorkAtHomeFlag(
										assignmentItem.getJSONObject(itemLenght).isNull(Constants.WORK_AT_HOME_FLAG)
												? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.WORK_AT_HOME_FLAG)));
								emp.setUserPersonType(
										assignmentItem.getJSONObject(itemLenght).isNull(Constants.USER_PERSON_TYPE) ? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.USER_PERSON_TYPE)));

								emp.setPositionId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.POSITION_ID)
										? ""
										: String.valueOf(
												assignmentItem.getJSONObject(itemLenght).get(Constants.POSITION_ID)));

								emp.setNormalHours(
										assignmentItem.getJSONObject(itemLenght).isNull(Constants.NORMAL_HOURS) ? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.NORMAL_HOURS)));

								emp.setFrequency(assignmentItem.getJSONObject(itemLenght).isNull(Constants.FREQUENCY)
										? ""
										: String.valueOf(
												assignmentItem.getJSONObject(itemLenght).get(Constants.FREQUENCY)));

								// Transformation is calculated into EmplWorkerModel.java class
								emp.setAssignmentCategory(
										assignmentItem.getJSONObject(itemLenght).isNull(Constants.ASSIGNMENT_CATEGORY)
												? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.ASSIGNMENT_CATEGORY)));

								// Calculate Start date for Pending Worker

								if (Constants.PENDING_WORKER.compareToIgnoreCase(emp.getWorkerType()) == 0) {

									emp.setProjectedStartDate(assignmentItem.getJSONObject(itemLenght)
											.isNull(Constants.PROJECTED_START_DATE) ? ""
													: String.valueOf(assignmentItem.getJSONObject(itemLenght)
															.get(Constants.PROJECTED_START_DATE)));

								} else {

									emp.setProjectedStartDate(emp.getHireDate());
								}

								// Set Pay Group Attribute
								emp.setPeopleGroup(
										assignmentItem.getJSONObject(itemLenght).isNull(Constants.PEOPLE_GROUP) ? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.PEOPLE_GROUP)));

								// Get Manager Assignment ID

								JSONArray managerItem = assignmentItem.getJSONObject(itemLenght)
										.getJSONArray(Constants.MANAGERS);

								if (managerItem != null && managerItem.length() != 0) {

									setLineManager(emp, managerItem);

								} else {
									emp.setManagerAssignmentId("");
								}

								// Check Employee type for Active Directory

								JSONArray assignmentsDFFItem = assignmentItem.getJSONObject(itemLenght)
										.getJSONArray(Constants.ASSIGNMENTS_DFF);

								if (assignmentsDFFItem != null && assignmentsDFFItem.length() != 0) {
									emp.setPayRule(
											assignmentsDFFItem.getJSONObject(itemLenght).isNull(Constants.PAY_RULE) ? ""
													: String.valueOf(assignmentsDFFItem.getJSONObject(itemLenght)
															.get(Constants.PAY_RULE)));
								} else {
									emp.setPayRule("");
								}

								// Stop loop if Active assignment is found in Multiple workrealtionship array
								// list
								if (emp.getAssignmentStatusType() == 1) {
									activeFlag=true;
									break;
								}

							}

						} // for
						
						if (!activeFlag) {
							LOGGER.info(METHOD_NAME + "workerRelationRecord ::::: "+workerRelationRecord);
							LOGGER.info(METHOD_NAME + " LatestServiceID ::::: "+latestServiceID);
							LOGGER.info(METHOD_NAME + " LatestStartDate ::::: "+latestStartDate);
							
							//================
							for (int i = 0; i < workRelationships.length(); i++) {
								workRelationships = items.getJSONObject(itemLenght)
										.getJSONArray(Constants.WORK_RELATION_SHIPS);
								
								String serviceid = workRelationships.getJSONObject(i).isNull(
										Constants.PERIODOFSERVICEID) ? "" : String.valueOf(
												workRelationships.getJSONObject(i).get(Constants.PERIODOFSERVICEID));
								
								if (serviceid.equals(latestServiceID)) {
									/*
									 * Below Code Added During Emp URL to Worker URL conversion change request
									 * ----------------------------------------------------------------------- 
									 */
									emp.setHireDate(
											workRelationships.getJSONObject(i).isNull(Constants.HIRE_DATE) ? ""
													: String.valueOf(workRelationships.getJSONObject(i)
															.get(Constants.HIRE_DATE)));
									emp.setTerminationDate(
											workRelationships.getJSONObject(i).isNull(Constants.TERMINATION_DATE) ? ""
													: String.valueOf(workRelationships.getJSONObject(i)
															.get(Constants.TERMINATION_DATE)));
									
									
									/*
									 * Above Code Added During Emp URL to Worker URL conversion change request
									 * ----------------------------------------------------------------------- 
									 */
									
									emp.setLegalEmployerName(
											workRelationships.getJSONObject(i).isNull(Constants.LEGALEMPLOYER_NAME) ? ""
													: String.valueOf(workRelationships.getJSONObject(i)
															.get(Constants.LEGALEMPLOYER_NAME)));

									emp.setWorkerType(workRelationships.getJSONObject(i).isNull(Constants.WORKER_TYPE) ? ""
											: String.valueOf(workRelationships.getJSONObject(i).get(Constants.WORKER_TYPE)));

									JSONArray assignmentItem = workRelationships.getJSONObject(i)
											.getJSONArray(Constants.ASSIGNMENTS);

									if (assignmentItem != null && assignmentItem.length() > 0) {
										/*
										 * Below Code Added to pull GradeId from Worker URL conversion change request
										 * ----------------------------------------------------------------------- 
										 */
										emp.setGradeId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.GRADE_ID) ? ""
												: String.valueOf(assignmentItem.getJSONObject(itemLenght)
														.get(Constants.GRADE_ID)));
										/*
										 * Above Code Added to pull GradeId from Worker URL conversion change request
										 * ----------------------------------------------------------------------- 
										 */
										emp.setJobCode(assignmentItem.getJSONObject(itemLenght).isNull(Constants.JOB_CODE) ? ""
												: String.valueOf(
														assignmentItem.getJSONObject(itemLenght).get(Constants.JOB_CODE)));

										emp.setLocationCode(
												assignmentItem.getJSONObject(itemLenght).isNull(Constants.LOCATION_CODE) ? ""
														: String.valueOf(assignmentItem.getJSONObject(itemLenght)
																.get(Constants.LOCATION_CODE)));

										emp.setDepartmentName(
												assignmentItem.getJSONObject(itemLenght).isNull(Constants.DEPARTMENT_NAME) ? ""
														: String.valueOf(assignmentItem.getJSONObject(itemLenght)
																.get(Constants.DEPARTMENT_NAME)));

										String status = String.valueOf(
												assignmentItem.getJSONObject(itemLenght).get(Constants.ASSIGNMENT_STATUS_TYPE));
										int statuskey;
										if (status.equalsIgnoreCase(Constants.ACTIVE)) {
											statuskey = 1;									
										}else {
											statuskey = 0;
										}
										// Set Status for employee
										emp.setAssignmentStatusType(statuskey);

										emp.setLocationId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.LOCATION_ID)
												? ""
												: String.valueOf(
														assignmentItem.getJSONObject(itemLenght).get(Constants.LOCATION_ID)));

										emp.setAssignmentId(
												assignmentItem.getJSONObject(itemLenght).isNull(Constants.ASSIGNMENT_ID) ? ""
														: String.valueOf(assignmentItem.getJSONObject(itemLenght)
																.get(Constants.ASSIGNMENT_ID)));

										emp.setActionCode(assignmentItem.getJSONObject(itemLenght).isNull(Constants.ACTION_CODE)
												? ""
												: String.valueOf(
														assignmentItem.getJSONObject(itemLenght).get(Constants.ACTION_CODE)));

										emp.setWorkAtHomeFlag(
												assignmentItem.getJSONObject(itemLenght).isNull(Constants.WORK_AT_HOME_FLAG)
														? ""
														: String.valueOf(assignmentItem.getJSONObject(itemLenght)
																.get(Constants.WORK_AT_HOME_FLAG)));
										emp.setUserPersonType(
												assignmentItem.getJSONObject(itemLenght).isNull(Constants.USER_PERSON_TYPE) ? ""
														: String.valueOf(assignmentItem.getJSONObject(itemLenght)
																.get(Constants.USER_PERSON_TYPE)));

										emp.setPositionId(assignmentItem.getJSONObject(itemLenght).isNull(Constants.POSITION_ID)
												? ""
												: String.valueOf(
														assignmentItem.getJSONObject(itemLenght).get(Constants.POSITION_ID)));

										emp.setNormalHours(
												assignmentItem.getJSONObject(itemLenght).isNull(Constants.NORMAL_HOURS) ? ""
														: String.valueOf(assignmentItem.getJSONObject(itemLenght)
																.get(Constants.NORMAL_HOURS)));

										emp.setFrequency(assignmentItem.getJSONObject(itemLenght).isNull(Constants.FREQUENCY)
												? ""
												: String.valueOf(
														assignmentItem.getJSONObject(itemLenght).get(Constants.FREQUENCY)));

										// Transformation is calculated into EmplWorkerModel.java class
										emp.setAssignmentCategory(
												assignmentItem.getJSONObject(itemLenght).isNull(Constants.ASSIGNMENT_CATEGORY)
														? ""
														: String.valueOf(assignmentItem.getJSONObject(itemLenght)
																.get(Constants.ASSIGNMENT_CATEGORY)));

										// Calculate Start date for Pending Worker

										if (Constants.PENDING_WORKER.compareToIgnoreCase(emp.getWorkerType()) == 0) {

											emp.setProjectedStartDate(assignmentItem.getJSONObject(itemLenght)
													.isNull(Constants.PROJECTED_START_DATE) ? ""
															: String.valueOf(assignmentItem.getJSONObject(itemLenght)
																	.get(Constants.PROJECTED_START_DATE)));

										} else {

											emp.setProjectedStartDate(emp.getHireDate());
										}

										// Set Pay Group Attribute
										emp.setPeopleGroup(
												assignmentItem.getJSONObject(itemLenght).isNull(Constants.PEOPLE_GROUP) ? ""
														: String.valueOf(assignmentItem.getJSONObject(itemLenght)
																.get(Constants.PEOPLE_GROUP)));

										// Get Manager Assignment ID

										JSONArray managerItem = assignmentItem.getJSONObject(itemLenght)
												.getJSONArray(Constants.MANAGERS);

										if (managerItem != null && managerItem.length() != 0) {

											setLineManager(emp, managerItem);

										} else {
											emp.setManagerAssignmentId("");
										}

										// Check Employee type for Active Directory

										JSONArray assignmentsDFFItem = assignmentItem.getJSONObject(itemLenght)
												.getJSONArray(Constants.ASSIGNMENTS_DFF);

										if (assignmentsDFFItem != null && assignmentsDFFItem.length() != 0) {
											emp.setPayRule(
													assignmentsDFFItem.getJSONObject(itemLenght).isNull(Constants.PAY_RULE) ? ""
															: String.valueOf(assignmentsDFFItem.getJSONObject(itemLenght)
																	.get(Constants.PAY_RULE)));
										} else {
											emp.setPayRule("");
										}
															
								} 

								break;

							} // if
							//================
							
						}

						}
						LOGGER.info(METHOD_NAME + "Completed User Record ::" + emp.toString());
					}

				} else {

					LOGGER.info("No record found in worker api for " + personNumber);
				}

			}
			LOGGER.info("Exit " + METHOD_NAME);
			return emp;

		} catch (Exception e) {

			e.printStackTrace();
			throw e;
		}

	}

	/**
	 * This method is used to get values of Line Manager from worker API response
	 * and set values into EmpWorkerModel POJO class.
	 * 
	 * @param emp This parameter is used to store value that are fetch from worker
	 *            API into EmpWorkerModel POJO class.
	 * @throws Exception Throws high level exception occurred in this class while
	 *                   executing custom code.
	 */

	public void setLineManager(EmpWorkerModel emp, JSONArray managerItem) {
		String METHOD_NAME = "ReadEmpWorkerRecord/setLineManager() ";
		LOGGER.info("##### Entering in setLineManager method #####" + METHOD_NAME);
		try {
			for (int index = 0; index < managerItem.length(); ++index) {

				String lineManager = managerItem.getJSONObject(index).isNull(Constants.MANAGER_TYPE) ? ""
						: String.valueOf(managerItem.getJSONObject(index).get(Constants.MANAGER_TYPE));

				if (!lineManager.isEmpty() && lineManager != null && lineManager.equals(Constants.LINE_MANAGER)) {
					emp.setManagerAssignmentId(managerItem.getJSONObject(index).isNull(Constants.MANAGER_ASSIGNMENT_ID)
							? ""
							: String.valueOf(managerItem.getJSONObject(index).get(Constants.MANAGER_ASSIGNMENT_ID)));
					LOGGER.info("Setting Line Manager for " + emp.getPersonNumber());
					break;
				} else {
					emp.setManagerAssignmentId("");
					LOGGER.info("Line Manager not found for employee" + emp.getPersonNumber());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			LOGGER.info("##### Exiting from setLineManager method #####");
		}
	}

}
