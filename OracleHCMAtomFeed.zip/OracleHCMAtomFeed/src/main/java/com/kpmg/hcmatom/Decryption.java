package com.kpmg.hcmatom;

import java.util.logging.Logger;

import org.jasypt.util.text.BasicTextEncryptor;

/**This class is used to decrypt encrypted passsword
 * @author ajinkyachavan
 *
 */
public class Decryption {


private final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);

	/**
	 * @param password Encrypted password is passed to password parameter of passwordDecrypt method.
	 * @return This method returns decrypted password to requested method.
	 * @throws Exception Throws high level exception occurred in this class while executing
	 *             custom code.
	 */
	public String passwordDecrypt(String password) throws Exception {
		String decryptedText = null;
		String METHOD_NAME = "Decryption/passwordDecrypt() ";
		try {
			LOGGER.info("Entered "+METHOD_NAME);
			String encryptedText = password; // convert ByteArray to String

			/*
			 * Decrypting password from config file
			 */
			BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
			
			// Given password at time of encryption
			textEncryptor.setPassword("zfzh0VLy5ZdMuacMxoRijdRSWvXp1L");

			decryptedText = textEncryptor.decrypt(encryptedText);

		}

		catch (Exception e) {

			e.printStackTrace();
			throw e;
		} finally {
			LOGGER.info("Exist "+METHOD_NAME);
		}
		return decryptedText;

	}

}
